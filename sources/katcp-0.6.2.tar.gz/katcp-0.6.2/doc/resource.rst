.. resource

***********************************************
Abstract High-level KATCP Client API (resource)
***********************************************

.. automodule:: katcp.resource
   :members:
   :show-inheritance:

