.. server

*************************
KATCP Server API (server)
*************************

.. automodule:: katcp.server
   :members:
   :show-inheritance:

