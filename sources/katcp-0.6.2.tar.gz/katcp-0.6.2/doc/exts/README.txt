The files

   LICENSE.txt
   numpydoc.py
   docscrape.py
   docscrapte_sphinx.py
   
have been copied from the numpy Sphinx extension SVN repository at
http://svn.scipy.org/svn/numpy/trunk/doc/sphinxext.

The file docscrape.py has been modified to add support for the
'Inform Arguments' section that is present in the docstrings of
katcp request handlers.
