.. Sampling

********
Sampling
********

.. automodule:: katcp.sampling
   :members:
   :show-inheritance:
