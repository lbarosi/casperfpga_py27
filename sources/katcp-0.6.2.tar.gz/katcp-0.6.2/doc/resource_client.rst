.. resource_client

******************************************************
Concrete High-level KATCP Client API (resource_client)
******************************************************

.. automodule:: katcp.resource_client
   :members:
   :show-inheritance:

