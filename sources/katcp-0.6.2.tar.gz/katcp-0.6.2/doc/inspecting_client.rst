.. inspecting_client

****************************************************************
Concrete Intermediate-level KATCP Client API (inspecting_client)
****************************************************************

.. automodule:: katcp.inspecting_client
   :members:
   :show-inheritance:

