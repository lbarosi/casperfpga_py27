.. Kattypes

********
Kattypes
********

.. automodule:: katcp.kattypes
   :members:
   :show-inheritance:

.. automodule does not pick up unpack_message since it is a partial
   object. autofunction here seems to do the right thing :)
.. autofunction:: katcp.kattypes.unpack_message
