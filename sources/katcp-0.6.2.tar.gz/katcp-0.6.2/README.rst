katcp-python
============

Python client and server library for the Karoo Array Telescope Control Protocol
(KATCP).  For more info, see the doc directory in this repository, or for online
documentation of the latest release see `pypi hosted katcp-python documentation
<http://packages.python.org/katcp/>`_.
