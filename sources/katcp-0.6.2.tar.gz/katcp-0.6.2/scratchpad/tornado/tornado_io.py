from katcp.server import *

import logging
import mock

