"""The empty module is here so that pylint can examine the scripts

   copyright (c) 2008 SKA/KAT. All Rights Reserved.
   @author Robert Crida <robert.crida@ska.ac.za>
   @date 2008-10-10
   """
