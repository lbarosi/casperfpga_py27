from setuptools import setup

setup(
    name='mypackage',
    version='0.1',
    author='Tres Seaver',
    author_email='tseaver@palladion.com',
    url='http://pypi.python.org/pypi/pkginfo',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Console (Text Based)',
    ],
)
