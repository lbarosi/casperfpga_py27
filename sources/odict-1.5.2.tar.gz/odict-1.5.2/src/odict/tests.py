# Python Software Foundation License

import unittest
import doctest
from pprint import pprint
from interlude import interact

optionflags = doctest.NORMALIZE_WHITESPACE | \
              doctest.ELLIPSIS | \
              doctest.REPORT_ONLY_FIRST_FAILURE

TESTFILES = [
    'pyodict.rst',
]


def test_suite():
    return unittest.TestSuite([
        doctest.DocFileSuite(
            test_file,
            optionflags=optionflags,
            globs={'interact': interact,
                   'pprint': pprint},
        ) for test_file in TESTFILES
    ])

if __name__ == '__main__':
    unittest.main(defaultTest='test_suite')                 #pragma NO COVERAGE
